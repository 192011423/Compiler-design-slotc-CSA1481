#include<stdio.h>
#define A 10
int main()
{
	b=20;
	printf("%d",A+b);
	printf("answer");
}