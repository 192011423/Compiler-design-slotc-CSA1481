#include<stdio.h> 
int main()
{
int a,b,c; /*varible declaration*/
printf("enter two numbers"); 
scanf("%d %d",&a,&b); 
c=a+b;//adding two numbers 
printf("sum is %d",c);
return 0;
}
